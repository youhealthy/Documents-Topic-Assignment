# Taxonomy-package

###########
# Funtion #
###########
Topic.func <- function(text, kgroups, lda.seed){
  require(chinese.misc)
  require(tm)
  require(jiebaR)
  require(topicmodels)
  require(SparseM)

  message(Sys.time())

  message("# Begin dtm generating dtm for input-text")
  dtm = corp_or_dtm(text, from = "v", type='dtm', stop_word='jiebar', control='auto2')
  message("# Finish dtm generating")

  message("# Begin k-means cluster")
  dtmA = dtm
  dtmA$v = dtm$v + 5
  # This 5 is an arbitrary selection depends on how different we treat zero and non-zero
  kmeans <- kmeans(dtmA, kgroups)
  message("# Finish k-means cluster")

  message("# Begin LDA")
  lda_vem <- LDA(dtm, k = kgroups, method = "VEM", control = list(seed = lda.seed))
  lda_gibbs <- LDA(dtm, k = kgroups, method = "Gibbs", control = list(seed = lda.seed))
  message("# Finish LDA (vtm and gibbs)")

  message("# Return grouping results")

  cluster_group = kmeans$cluster

  GroupsAssign_vem =  lda_vem@gamma
  rownames(GroupsAssign_vem) = rep(1:lda_vem@Dim[1])
  colnames(GroupsAssign_vem) = sapply(rep(1:lda_vem@k), function(x) paste("Group", x) )
  LDA_vem_group = as.vector(unlist(apply(GroupsAssign_vem, 1, which.max)))

  GroupsAssign_gibbs =  lda_gibbs@gamma
  rownames(GroupsAssign_gibbs) = rep(1:lda_gibbs@Dim[1])
  colnames(GroupsAssign_gibbs) = sapply(rep(1:lda_gibbs@k), function(x) paste("Group", x) )
  LDA_gibbs_group = as.vector(unlist(apply(GroupsAssign_gibbs, 1, which.max)))

  message(Sys.time())

  return( list( cluster_result = kmeans,
                LDA_result = list(vem = lda_vem, gibbs = lda_gibbs),
                cluster_group = cluster_group,
                LDA_group = list(vem = LDA_vem_group, gibbs = LDA_gibbs_group)) )
}
